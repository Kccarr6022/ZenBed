# -*- coding: utf-8 -*-
# Grid size
MOTORGRIDXSIZE = 12
MOTORGRIDYSIZE = 18


class Pattern:
    def __init__(self) -> None:
        self.time = 0.1  # default time per frame
        self.percent_power = 100 # default percentage power
        self.start_power = 10 # default start power
        self.max_power = 40 # default max power
        self.rate_of_change = 5 # default rate of change
        self.sequence = "" # default sequence
        pass

