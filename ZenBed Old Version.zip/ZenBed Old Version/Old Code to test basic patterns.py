def testallmotors():
    for i in range(0, 15):
        PCA = PCA9685(i2c_bus, 0x40 + i)
        PCA.frequency = 60
        for j in range(0, 15):
            PCA.channels[j].duty_cycle = int(0xFFFF * 50 / 100)
    time.sleep(10)
    for i in range(0, 15):
        PCA = PCA9685(i2c_bus, 0x40 + i)
        PCA.frequency = 1600
        for j in range(0, 15):
            PCA.channels[j].duty_cycle = int(0xFFFF * 0 / 100)
    
    

def main():
    testallmotors()
